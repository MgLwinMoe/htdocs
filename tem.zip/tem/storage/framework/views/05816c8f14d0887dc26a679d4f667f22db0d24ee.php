<div class="bg-dark">
    <div class="container">
        <div class="row">
            <div class="col">Language</div>
            <div class="col">
                <div class="row">
                    <div class="col">Phone</div>
                    <div class="col">Contact</div>
                    <div class="col">Contact</div>
                </div>
            </div>
            <div class="col">Language</div>
        </div>
    </div>
</div><?php /**PATH C:\Users\User\Desktop\Project\Laravel\PLWP\resources\views/website/footer.blade.php ENDPATH**/ ?>