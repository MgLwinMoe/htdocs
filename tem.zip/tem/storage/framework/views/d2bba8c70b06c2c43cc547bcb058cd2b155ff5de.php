<div class="bg-primary">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class="row">
                    <div class="col">Phone</div>
                    <div class="col">Contact</div>
                </div>
            </div>
            <div class="col">Language</div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tem\resources\views/website/header.blade.php ENDPATH**/ ?>