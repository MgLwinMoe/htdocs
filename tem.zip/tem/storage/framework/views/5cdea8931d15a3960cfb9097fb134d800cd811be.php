

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="text-center pb-4">
                <?php echo csrf_field(); ?>
                <div class="d-inline-block w-25 p-2">
                    <img src="/images/logo-480.png" class="w-50" alt="PLWP | Online Clinic | Logo">
                </div>
            </div>
            <div class="card p-4s">
                <div class="card-header">
                    <h3 class="text-center"><?php echo e(__('Verify Your Email Address')); ?></h3>
                </div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                        </div>
                    <?php endif; ?>
                    <h5 class="text-center">
                        <?php echo e(__('Before proceeding, please check your email for a verification link.')); ?>

                    </h5>
                    <div class="text-center">
                        <img src="/images/email-mail-verify.png" alt="PLWP | Email Icon" class="w-25">
                    </div>
                    <?php echo e(__('If you did not receive the email')); ?>,
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('click here to request another')); ?></button>.
                    </form>
                </div>
                <div class="card-footer">
                    <form id="logoutform" action="<?php echo e(route('logout')); ?>" method="POST" >
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-dark text-white px-3 py-0 float-right">Logout</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\User\Desktop\Project\Laravel\PLWP\resources\views/auth/verify.blade.php ENDPATH**/ ?>