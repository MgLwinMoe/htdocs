<?php

return [
    'site_title' => 'PLWP Dashboard',
];